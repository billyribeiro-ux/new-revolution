import concurrent.futures, datetime, hashlib, json, re, urllib.request, urllib.error
from html.parser import HTMLParser
from pathlib import Path
ROOT=Path('/Users/billyribeiro/dev/new-revolution-web')
OUT=ROOT/'docs/seo/audit/2026-11-15/sources'
class Text(HTMLParser):
 def __init__(self): super().__init__(); self.skip=0; self.parts=[]; self.links=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag in ['script','style']: self.skip+=1
  if tag=='a' and a.get('href'): self.links.append(a['href'])
  if tag in ['h1','h2','h3','p','li','tr','div','br','section','article']: self.parts.append('\n')
 def handle_endtag(self,tag):
  if tag in ['script','style']: self.skip=max(0,self.skip-1)
  if tag in ['h1','h2','h3','p','li','tr']: self.parts.append('\n')
 def handle_data(self,data):
  if not self.skip:self.parts.append(data)
def fetch(url):
 key=hashlib.sha256(url.encode()).hexdigest()[:14]
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'RevolutionTechnicalSEOAudit/1.0'})
  with urllib.request.urlopen(req,timeout=45) as r: raw=r.read(); status=r.status; final=r.url; headers=dict(r.headers)
  html=raw.decode('utf-8','replace'); p=Text();p.feed(html)
  txt=re.sub(r'[\t \r\f\v]+',' ',''.join(p.parts));txt=re.sub(r'\n\s*\n+','\n',txt).strip()
  (OUT/(key+'.html')).write_text(html);(OUT/(key+'.txt')).write_text(txt)
  dates=re.findall(r'Last updated[^\n]{0,100}',txt)
  return {'url':url,'finalUrl':final,'status':status,'headers':headers,'bytes':len(raw),'textCharacters':len(txt),'sha256':hashlib.sha256(raw).hexdigest(),'lastUpdated':dates,'htmlFile':key+'.html','textFile':key+'.txt','links':p.links,'fetchedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 except Exception as e:return {'url':url,'error':str(e),'fetchedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
paths=['docs/appearance/title-link','docs/appearance/snippet','docs/appearance/google-discover','docs/appearance/site-names','docs/appearance/favicon-in-search','docs/appearance/ai-features','docs/appearance/core-web-vitals','docs/crawling-indexing/consolidate-duplicate-urls','docs/crawling-indexing/robots-meta-tag','docs/crawling-indexing/robots/intro','docs/crawling-indexing/robots/create-robots-txt','docs/crawling-indexing/sitemaps/build-sitemap','docs/crawling-indexing/http-network-errors','docs/crawling-indexing/links-crawlable','docs/crawling-indexing/url-structure','docs/crawling-indexing/control-what-you-share','docs/crawling-indexing/google-common-crawlers','docs/crawling-indexing/mobile/mobile-sites-mobile-first-indexing','docs/specialty/international/localized-versions','docs/specialty/international/locale-adaptive-pages','docs/specialty/ecommerce/pagination-and-incremental-page-loading','docs/appearance/structured-data/search-gallery','docs/appearance/structured-data/intro-structured-data','docs/appearance/structured-data/sd-policies','docs/appearance/structured-data/article','docs/appearance/structured-data/breadcrumb','docs/appearance/structured-data/course','docs/appearance/structured-data/organization','docs/appearance/structured-data/product-snippet','docs/appearance/structured-data/software-app','docs/appearance/structured-data/review-snippet','docs/appearance/structured-data/discussion-forum','docs/appearance/structured-data/profile-page','docs/appearance/structured-data/paywalled-content','docs/appearance/structured-data/speakable','docs/appearance/structured-data/video','docs/appearance/structured-data/faqpage','docs/appearance/structured-data/how-to','docs/essentials/spam-policies','docs/fundamentals/using-gen-ai-content','docs/fundamentals/creating-helpful-content','docs/crawling-indexing/qualify-outbound-links','docs/appearance/page-experience','updates','blog','blog/2025/06/simplifying-search-results','blog/2025/11/update-on-our-efforts','blog/2024/10/sitelinks-search-box','blog/2026/10/ai-training-control','blog/2023/06/sitemaps-lastmod-ping']
urls=['https://developers.google.com/search/'+p for p in paths]+['https://status.search.google.com/summary','https://web.dev/articles/vitals','https://web.dev/articles/cls','https://web.dev/articles/inp','https://web.dev/articles/optimize-webfont-loading','https://ogp.me/','https://developer.x.com/en/docs/x-for-websites/cards/overview/summary-card-with-large-image','https://developers.google.com/search/docs/monitor-debug/search-console-start','https://developers.google.com/search/docs/appearance/structured-data','https://svelte.dev/docs/kit/configuration']
with concurrent.futures.ThreadPoolExecutor(max_workers=7) as ex:
 results=list(ex.map(fetch,urls))
blog=next((r for r in results if r['url']=='https://developers.google.com/search/blog'),{})
more=set()
for link in blog.get('links',[]):
 m=re.search(r'(?:https://developers.google.com)?(/search/blog/(2026)/(0[5-9]|1[01])/[^?#]+)',link)
 if m:more.add('https://developers.google.com'+m[1])
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:results+=list(ex.map(fetch,sorted(more)))
(OUT/'index.json').write_text(json.dumps(results,indent=2))
print(json.dumps({'sources':len(results),'success':sum(r.get('status')==200 for r in results),'errors':[{'url':r['url'],'error':r['error']} for r in results if 'error'in r],'blogPosts':len(more)},indent=2))
