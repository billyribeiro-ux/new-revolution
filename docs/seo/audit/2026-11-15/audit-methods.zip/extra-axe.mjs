import fs from 'node:fs/promises';
import { chromium } from 'playwright';
import AxeBuilder from '@axe-core/playwright';
const browser=await chromium.launch({headless:true});const results=[];
try{for(const path of ['/admin/login','/store/courses','/store/courses/move-prior-to-the-move-ultra','/blog/category/market-structure']){
 const page=await browser.newPage({viewport:{width:390,height:900}});const r=await page.goto('http://127.0.0.1:4176'+path,{waitUntil:'networkidle'});
 const a=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21aa','wcag22aa']).analyze();
 results.push({path,status:r?.status(),violations:a.violations.map(v=>({id:v.id,impact:v.impact,nodes:v.nodes.map(n=>({target:n.target,html:n.html}))})),passes:a.passes.length});await page.close();
}}finally{await browser.close();await fs.writeFile('/Users/billyribeiro/dev/new-revolution-web/docs/seo/audit/2026-11-15/additional-template-axe.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2))}
