from pathlib import Path
ns={};exec(Path('/tmp/revolution-seo-fetch.py').read_text().split('paths=')[0],ns)
ns['OUT']=Path('/tmp/revolution-seo-raw')
urls=['https://developers.google.com/search/docs/fundamentals/ai-optimization-guide','https://developers.google.com/search/docs/crawling-indexing/301-redirects','https://developers.google.com/search/docs/appearance/google-images','https://developers.google.com/search/docs/crawling-indexing/sitemaps/image-sitemaps','https://developers.google.com/search/docs/crawling-indexing/javascript/lazy-loading','https://developers.google.com/search/docs/monitor-debug/prevent-abuse','https://web.dev/articles/vitals','https://svelte.dev/docs/kit/configuration','https://developers.google.com/search/docs/monitor-debug/prevent-abuse']
import json,concurrent.futures
with concurrent.futures.ThreadPoolExecutor(max_workers=5)as ex:extra=list(ex.map(ns['fetch'],set(urls)))
p=ns['OUT']/'index.json';old=json.loads(p.read_text());p.write_text(json.dumps(list({r['url']:r for r in old+extra}.values()),indent=2))
print(json.dumps([{k:r.get(k)for k in ['url','status','finalUrl','lastUpdated','error']}for r in extra],indent=2))
