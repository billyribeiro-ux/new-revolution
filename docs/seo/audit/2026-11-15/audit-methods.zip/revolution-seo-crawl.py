import concurrent.futures,datetime,hashlib,json,re,sys,urllib.request,urllib.parse,urllib.error,uuid,collections
from pathlib import Path
from html.parser import HTMLParser
ROOT=Path('/Users/billyribeiro/dev/new-revolution-web');OUT=ROOT/'docs/seo/audit/2026-11-15';RAW=Path('/tmp/revolution-seo-http');RAW.mkdir(exist_ok=True)
BASE=sys.argv[1].rstrip('/');LABEL=sys.argv[2]
class Parser(HTMLParser):
 def __init__(self):
  super().__init__();self.title=[];self.meta=collections.defaultdict(list);self.canonical=[];self.links=[];self.images=[];self.ld=[];self.headings=[];self.text=[];self.stack=[];self.capture=None;self.buf=[];self.html={};self.landmarks=collections.Counter();self.times=[];self.crumbs=[];self.fontlinks=[]
 def handle_starttag(self,t,a):
  a=dict(a);self.stack.append((t,a))
  if t=='html':self.html=a
  self.landmarks[t]+=1
  if t=='meta':self.meta[a.get('name',a.get('property',a.get('charset','charset'))) .lower()].append(a.get('content',a.get('charset','')))
  if t=='link':
   if a.get('rel')=='canonical':self.canonical.append(a.get('href'))
   if a.get('as')=='font' or 'fonts.googleapis' in a.get('href',''):self.fontlinks.append(a)
  if t=='a':self.links.append({'href':a.get('href',''),'text':'','rel':a.get('rel','')})
  if t=='img':self.images.append(a)
  if t=='time':self.times.append(a)
  if t=='title' or re.fullmatch('h[1-6]',t) or (t=='script' and a.get('type')=='application/ld+json'):self.capture=t;self.buf=[]
 def handle_endtag(self,t):
  if self.capture==t:
   s=''.join(self.buf).strip()
   if t=='title':self.title.append(s)
   elif t=='script':
    try:self.ld.append({'parsed':json.loads(s)})
    except Exception as e:self.ld.append({'parseError':str(e),'raw':s})
   else:self.headings.append({'level':int(t[1]),'text':s})
   self.capture=None;self.buf=[]
  for i in range(len(self.stack)-1,-1,-1):
   if self.stack[i][0]==t:self.stack=self.stack[:i];break
 def handle_startendtag(self,t,a):self.handle_starttag(t,a);self.handle_endtag(t)
 def handle_data(self,s):
  if self.capture:self.buf.append(s)
  if not any(t in ['script','style'] for t,a in self.stack):
   self.text.append(s)
   if any(t=='a' for t,a in self.stack) and self.links:self.links[-1]['text']+=s
   if any(t=='nav' and a.get('aria-label','').lower()=='breadcrumb' for t,a in self.stack):self.crumbs.append(s.strip())
class Redirect(urllib.request.HTTPRedirectHandler):
 def __init__(self):self.hops=[]
 def redirect_request(self,req,fp,code,msg,headers,newurl):self.hops.append({'url':req.full_url,'status':code,'location':newurl});return super().redirect_request(req,fp,code,msg,headers,newurl)
def fetch(path,headers=None):
 url=path if path.startswith('http') else BASE+path;r=Redirect();op=urllib.request.build_opener(r)
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 RevolutionSEOAudit',**(headers or {})})
  try:res=op.open(req,timeout=30)
  except urllib.error.HTTPError as e:res=e
  with res:raw=res.read();return {'requestedUrl':url,'finalUrl':res.url,'status':res.status,'headers':dict(res.headers),'redirectChain':r.hops,'body':raw.decode('utf-8','replace')}
 except Exception as e:return {'requestedUrl':url,'error':str(e),'body':''}
def analyze(r):
 body=r.pop('body','');p=Parser();p.feed(body);text=re.sub(r'\s+',' ',''.join(p.text)).strip();r.update({'title':p.title,'meta':dict(p.meta),'canonical':p.canonical,'html':p.html,'headings':p.headings,'jsonLd':p.ld,'links':p.links,'images':p.images,'times':p.times,'breadcrumbs':p.crumbs,'landmarks':{t:p.landmarks[t] for t in ['header','nav','main','footer']},'fontLinks':p.fontlinks,'bodyText':text,'rawHash':hashlib.sha256(body.encode()).hexdigest()})
 key=hashlib.sha256(r['requestedUrl'].encode()).hexdigest()[:16];(RAW/(LABEL+'-'+key+'.html')).write_text(body);r['rawFile']=LABEL+'-'+key+'.html';r['problems']=problems(r);return r
def problems(r):
 if r.get('status')!=200:return ['HTTP-'+str(r.get('status',r.get('error')))]
 if not r.get('headings'):return ['NO-HEADINGS']
 noindex=any('noindex'in x for x in r.get('meta',{}).get('robots',[]));es=[]
 if len(r['title'])!=1:es.append('TITLE-COUNT')
 if len(r['meta'].get('description',[]))!=1:es.append('DESCRIPTION-COUNT')
 if not noindex and len(r['canonical'])!=1:es.append('CANONICAL-COUNT')
 if noindex and r['canonical']:es.append('NOINDEX-CANONICAL')
 if len([h for h in r['headings'] if h['level']==1])!=1:es.append('H1-COUNT')
 if r['html'].get('lang')!='en':es.append('LANG')
 if not r['landmarks']['main']:es.append('MAIN-LANDMARK')
 for tag in ['robots','og:title','og:description','og:url','og:image','og:type','og:site_name','og:locale','og:image:alt','twitter:card']:
  if len(r['meta'].get(tag,[]))!=1:es.append(tag.upper()+'-COUNT')
 if r['canonical'] and r['meta'].get('og:url')!=r['canonical']:es.append('OG-CANONICAL')
 if any('alt' not in im for im in r['images']):es.append('IMG-ALT')
 if any(not im.get('width') or not im.get('height') for im in r['images']):es.append('IMG-DIMENSIONS-REVIEW')
 if not r['jsonLd'] and not noindex:es.append('JSONLD-MISSING')
 if any('parseError'in b for b in r['jsonLd']):es.append('JSONLD-PARSE')
 levels=[h['level'] for h in r['headings']]
 if any(b>a+1 for a,b in zip(levels,levels[1:])):es.append('HEADING-SKIP')
 types=[];crumb=[]
 def walk(n):
  if isinstance(n,list):
   for x in n:walk(x)
  elif isinstance(n,dict):
   t=n.get('@type');types.extend(t if isinstance(t,list) else [t] if t else [])
   if t=='BreadcrumbList':crumb.extend(x.get('name','') for x in n.get('itemListElement',[]))
   for v in n.values():walk(v)
 for b in r['jsonLd']:walk(b.get('parsed'))
 r['schemaTypes']=sorted(set(types));r['schemaBreadcrumbs']=crumb
 if set(types)&{'FAQPage','HowTo','Course','CourseInstance','SpeakableSpecification','SpecialAnnouncement','ClaimReview'}:es.append('RESTRICTED-SCHEMA')
 if crumb and any(c.lower()not in ' '.join(r['breadcrumbs']).lower()for c in crumb):es.append('BREADCRUMB-PARITY')
 if r['fontLinks']:es.append('FONT-HREF')
 return es
# Prove independent checker rejects a broken fixture.
fixture={'status':200,'headings':[{'level':1,'text':'test'}],'title':[],'meta':{},'canonical':[],'html':{},'landmarks':{'main':1},'images':[],'jsonLd':[],'fontLinks':[],'breadcrumbs':[]}
assert 'TITLE-COUNT' in problems(fixture)
sitemap=fetch('/sitemap.xml');robots=fetch('/robots.txt');rss=fetch('/rss.xml')
locs=re.findall(r'<loc>([^<]+)</loc>',sitemap['body']);paths={urllib.parse.urlsplit(u).path or '/' for u in locs}
old=json.loads((ROOT/'docs/seo/audit/02-inventory.json').read_text());paths.update(x['url'] for x in old)
for f in (ROOT/'src/routes').rglob('+page.svelte'):
 rel=str(f.parent.relative_to(ROOT/'src/routes'));path='/'+re.sub(r'\([^/]+\)/?','',rel)
 if '['not in path and not path.startswith('/admin'):paths.add(path if path!='/. ' and rel!='.' else '/')
paths.update(['/','/live-trading-rooms','/admin/login'])
records={};pending=sorted(paths);rounds=0
while pending and rounds<4:
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
  for rec in ex.map(lambda p:analyze(fetch(p)),pending):records[urllib.parse.urlsplit(rec['requestedUrl']).path or '/']=rec
 new=set()
 for rec in records.values():
  for a in rec['links']:
   u=urllib.parse.urlsplit(urllib.parse.urljoin(rec.get('finalUrl',BASE),a['href']))
   if u.hostname in ['revolutiontradingpros.com','www.revolutiontradingpros.com','localhost','127.0.0.1'] and not re.search(r'\.(png|jpg|svg|webp|pdf|woff2?|ico|css|js|xml|txt)$',u.path) and not u.path.startswith(('/api/','/media/','/_app/')) and u.path not in records:new.add(u.path or '/')
 pending=sorted(new);rounds+=1
# No app data is mutated; probe response variants and unknown paths.
probePaths=['/'+str(uuid.uuid4()),'/blog/__seo_missing_20261115','/blog/category/__seo_missing_20261115','/blog/tag/__seo_missing_20261115','/store/courses/__seo_missing_20261115','/store/indicators/__seo_missing_20261115','/store/scanners/__seo_missing_20261115','/about/','/ABOUT','/blog?page=999999','/blog?search=__seo_probe__','/?blogPage=999999']
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as ex:probes=list(ex.map(lambda p:analyze(fetch(p)),probePaths))
variants=[]
for path in sorted({urllib.parse.urlsplit(u).path or '/' for u in locs}):
 clean=records.get(path,{})
 for name,h,q in [('googlebot',{'User-Agent':'Googlebot'},''),('mobile',{'User-Agent':'Mozilla/5.0 (iPhone; Mobile)'},''),('language',{'Accept-Language':'fr-FR,fr;q=0.9'},''),('cookie',{'Cookie':'locale=fr; e2e=1'},''),('forwarded',{'X-Forwarded-Host':'seo-probe.invalid','X-Forwarded-Proto':'http'},''),('query',{},'?utm_source=seo-audit&sort=1')]:
  r=analyze(fetch(path+q,h));variants.append({'path':path,'variant':name,'status':r.get('status'),'canonical':r['canonical'],'robots':r['meta'].get('robots'),'xRobotsTag':r.get('headers',{}).get('x-robots-tag'),'bodyIdentical':r['bodyText']==clean.get('bodyText'),'title':r['title'],'rawFile':r['rawFile'],'cacheControl':r.get('headers',{}).get('Cache-Control',r.get('headers',{}).get('cache-control'))})
# BFS and duplicate analysis.
depth={'/':0};queue=collections.deque(['/'])
while queue:
 path=queue.popleft()
 for a in records.get(path,{}).get('links',[]):
  u=urllib.parse.urlsplit(urllib.parse.urljoin(BASE+path,a['href']));target=u.path or '/'
  if u.hostname in ['revolutiontradingpros.com','www.revolutiontradingpros.com','localhost','127.0.0.1'] and target in records and target not in depth:depth[target]=depth[path]+1;queue.append(target)
for path,r in records.items():r['clickDepth']=depth.get(path)
dups={}
for field in ['title','description']:
 groups=collections.defaultdict(list)
 for path,r in records.items():
  if r.get('status')==200 and not any('noindex'in s for s in r['meta'].get('robots',[])):
   for val in (r['title'] if field=='title'else r['meta'].get('description',[])):groups[val].append(path)
 dups[field]={k:v for k,v in groups.items()if len(v)>1}
report={'generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':BASE,'label':LABEL,'fixtureCaught':True,'sitemap':sitemap,'robots':robots,'rss':rss,'sitemapLocs':locs,'records':records,'probes':probes,'variants':variants,'duplicates':dups,'orphans':[p for p in paths if p not in depth],'crawlRounds':rounds,'pendingNotFetched':pending}
(OUT/(LABEL+'-crawl.json')).write_text(json.dumps(report,indent=2))
print(json.dumps({'urls':len(records),'sitemap':len(locs),'statuses':dict(collections.Counter(r.get('status','error')for r in records.values())),'problems':dict(collections.Counter(e for r in records.values()for e in r['problems'])),'duplicates':dups,'orphans':report['orphans']},indent=2))
