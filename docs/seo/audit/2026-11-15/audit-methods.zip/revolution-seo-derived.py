import json,re,collections,urllib.parse
from pathlib import Path
root=Path('/Users/billyribeiro/dev/new-revolution-web');out=root/'docs/seo/audit/2026-11-15';d=json.loads((out/'production-crawl.json').read_text());rows=[]
for url in d['sitemapLocs']:
 path=urllib.parse.urlsplit(url).path or '/';r=d['records'][path];defs=set();refs=[];duplicates=[];types=[];strings=[]
 def walk(v):
  if isinstance(v,list):
   for x in v:walk(x)
  elif isinstance(v,dict):
   if '@id'in v:
    if len(v)>1:
     if v['@id'] in defs:duplicates.append(v['@id'])
     defs.add(v['@id'])
    else:refs.append(v['@id'])
   if '@type'in v:types.extend(v['@type']if isinstance(v['@type'],list)else[v['@type']])
   for x in v.values():walk(x)
  elif isinstance(v,str):strings.append(v)
 for block in r['jsonLd']:walk(block.get('parsed'))
 rows.append({'url':url,'path':path,'status':r.get('status'),'titleLength':len(r['title'][0])if r['title'] else 0,'descriptionLength':len(r['meta'].get('description',[''])[0]),'canonicalMatchesSitemap':r['canonical']==[url],'oneGraph':len(r['jsonLd'])==1 and '@graph'in r['jsonLd'][0].get('parsed',{}),'graphContext':all(b.get('parsed',{}).get('@context')=='https://schema.org'for b in r['jsonLd']),'types':sorted(set(types)),'unresolvedLocalReferences':sorted({x for x in refs if x not in defs and x.startswith('https://www.revolutiontradingpros.com')}),'duplicateDefinedIds':duplicates,'bylineLink':any('/about'in a['href']for a in r['links']),'visibleDates':r['times'],'containsUnverifiedPerformanceClaims':bool(re.search('600%|2020 COVID Top|2022 Market Top',r['bodyText'])),'problems':r['problems'],'clickDepth':r['clickDepth'],'mentionsUnavailable':bool(re.search('unavailable|not available|not currently|concept in development',r['bodyText'],re.I))})
(out/'03-url-summary.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
