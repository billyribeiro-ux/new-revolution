import fs from 'node:fs/promises';
import { chromium } from 'playwright';
import AxeBuilder from '@axe-core/playwright';
const root='/Users/billyribeiro/dev/new-revolution-web';
const dir=root+'/docs/seo/audit/2026-11-15';
const crawl=JSON.parse(await fs.readFile(dir+'/production-crawl.json','utf8'));
const urls=crawl.sitemapLocs;
const browser=await chromium.launch({headless:true});
const results=[];
try{
for(const url of urls){
 const context=await browser.newContext();const page=await context.newPage();const errors=[];const fonts=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(r.resourceType()==='font')fonts.push(r.url())});
 const widths=[];
 for(const width of [320,768,1536]){
  await page.setViewportSize({width,height:900});
  const res=await page.goto(url,{waitUntil:'networkidle'});await page.evaluate(()=>document.fonts.ready);
  const data=await page.evaluate(()=>({title:document.title,canonical:[...document.querySelectorAll('link[rel=canonical]')].map(x=>x.href),robots:[...document.querySelectorAll('meta[name=robots]')].map(x=>x.content),h1:[...document.querySelectorAll('h1')].map(x=>x.textContent.trim()),mainText:document.querySelector('main')?.textContent.replace(/\s+/g,' ').trim(),overflow:document.documentElement.scrollWidth-document.documentElement.clientWidth,h1Font:getComputedStyle(document.querySelector('h1')).fontFamily,bodyFont:getComputedStyle(document.body).fontFamily,jsonLd:[...document.querySelectorAll('script[type="application/ld+json"]')].map(x=>JSON.parse(x.textContent)),brokenImages:[...document.images].filter(x=>x.complete&&!x.naturalWidth).map(x=>x.currentSrc),bodyHeight:document.body.scrollHeight}));
  widths.push({width,status:res?.status(),...data});
 }
 await page.setViewportSize({width:390,height:900});
 const axe=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21aa','wcag22aa']).analyze();
 let enlarged=null,spacing=null;
 if(url.endsWith('/about')||url.endsWith('/day-trading-room')||url.endsWith('/0dte-spx-options-strategy-guide')||url==='https://www.revolutiontradingpros.com'){
  await page.addStyleTag({content:'html{font-size:200%!important}'});
  enlarged=await page.evaluate(()=>({overflow:document.documentElement.scrollWidth-document.documentElement.clientWidth}));
  await page.addStyleTag({content:'*{line-height:1.5!important;letter-spacing:.12em!important;word-spacing:.16em!important}p{margin-bottom:2em!important}'});
  spacing=await page.evaluate(()=>({overflow:document.documentElement.scrollWidth-document.documentElement.clientWidth}));
 }
 results.push({url,widths,textEqual:widths.every(x=>x.mainText===widths[0].mainText),axe:{violations:axe.violations.map(v=>({id:v.id,impact:v.impact,description:v.description,helpUrl:v.helpUrl,nodes:v.nodes.map(n=>({target:n.target,html:n.html,failureSummary:n.failureSummary}))})),incomplete:axe.incomplete.length,passes:axe.passes.length},enlarged,spacing,errors,fonts:[...new Set(fonts)]});
 console.log(url,'axe',axe.violations.map(v=>v.id+':'+v.impact).join(','),'overflow',widths.map(x=>x.overflow));
 await context.close();
}
}finally{await browser.close();await fs.writeFile(dir+'/browser-audit.json',JSON.stringify({generatedAt:new Date().toISOString(),results},null,2))}
