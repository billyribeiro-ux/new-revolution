import json,urllib.request,urllib.error
from pathlib import Path
class Redirect(urllib.request.HTTPRedirectHandler):
 def __init__(self):self.hops=[]
 def redirect_request(self,req,fp,code,msg,headers,url):self.hops.append({'url':req.full_url,'status':code,'location':url});return super().redirect_request(req,fp,code,msg,headers,url)
rows=[]
for url in ['http://revolutiontradingpros.com/','http://www.revolutiontradingpros.com/','https://revolutiontradingpros.com/','https://www.revolutiontradingpros.com/','https://www.revolutiontradingpros.com/images/blog/seo-audit-missing-image.webp']:
 r=Redirect();op=urllib.request.build_opener(r)
 try:
  with op.open(url,timeout=25)as res:raw=res.read();rows.append({'url':url,'finalUrl':res.url,'status':res.status,'headers':dict(res.headers),'chain':r.hops,'bodyType':raw[:70].decode('utf-8','replace')})
 except Exception as e:rows.append({'url':url,'error':str(e),'chain':r.hops})
Path('/Users/billyribeiro/dev/new-revolution-web/docs/seo/audit/2026-11-15/03-host-and-image-probes.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
